from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.models.database import get_db
from app.models.models import Case, Finding
from app.ai.manager import ai_manager

# Set up Jinja2 templates directory
templates = Jinja2Templates(directory="frontend/templates")
web_router = APIRouter(tags=["Web Dashboard"])
ai_router = APIRouter(prefix="/api/v1/ai", tags=["AI Engine"])

@web_router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, db: Session = Depends(get_db)):
    """Phase 9: Renders the main web dashboard."""
    cases = db.query(Case).all()
    open_findings = db.query(Finding).filter(Finding.status == "Open").count()
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "cases": cases,
        "total_cases": len(cases),
        "open_findings": open_findings
    })

@ai_router.post("/{finding_id}/analyze")
async def analyze_finding(finding_id: int, db: Session = Depends(get_db)):
    """Phase 10: Triggers AI correlation and analysis on a specific finding."""
    finding = db.query(Finding).filter(Finding.id == finding_id).first()
    if not finding:
        return {"error": "Finding not found"}
    
    # Construct context for the AI
    context = f"Vulnerability: {finding.title}\nAsset: {finding.affected_asset}\nSeverity: {finding.severity}"
    evidence = finding.description
    
    # Request analysis
    analysis_result = ai_manager.analyze_finding(context, evidence)
    
    # Update finding with AI review
    finding.ai_generated = True
    finding.description += f"\n\n--- AI ANALYSIS ---\n{analysis_result['analysis']}"
    db.commit()
    
    return {"status": "success", "analysis": analysis_result}
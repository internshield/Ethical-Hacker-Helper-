import os
import logging
from datetime import datetime
from jinja2 import Environment, FileSystemLoader
from weasyprint import HTML, CSS
from app.models.models import Case
from app.config import settings

logger = logging.getLogger("CyberForge.Reporting")

class ReportGenerator:
    """Phase 11: Transforms Database findings into professional HTML and PDF reports."""
    
    def __init__(self):
        self.export_dir = "./data/exports"
        os.makedirs(self.export_dir, exist_ok=True)
        # Setup Jinja2 environment specifically for reports
        self.env = Environment(loader=FileSystemLoader("frontend/templates"))

    def generate_pdf_report(self, case: Case) -> str:
        """Compiles the case data, renders HTML, and converts to a styled PDF."""
        template = self.env.get_template("report_template.html")
        
        # Prepare context data
        context = {
            "company_name": settings.APP_NAME,
            "case_name": case.name,
            "client": case.client,
            "date": datetime.utcnow().strftime("%B %d, %Y"),
            "operator": case.operator,
            "scope": case.scope,
            "findings": case.findings
        }
        
        # Render HTML string
        html_out = template.render(context)
        
        # Define output path
        filename = f"Assessment_Report_{case.id}_{datetime.utcnow().strftime('%Y%m%d')}.pdf"
        filepath = os.path.join(self.export_dir, filename)
        
        # Generate PDF using WeasyPrint with minimal corporate styling
        try:
            HTML(string=html_out).write_pdf(
                filepath,
                stylesheets=[CSS(string='@page { size: A4; margin: 2cm; } body { font-family: sans-serif; }')]
            )
            logger.info(f"Report successfully generated at: {filepath}")
            return filepath
        except Exception as e:
            logger.error(f"Failed to generate PDF report: {e}")
            raise RuntimeError("PDF Compilation Failed. Ensure WeasyPrint system dependencies are installed.")

report_generator = ReportGenerator()
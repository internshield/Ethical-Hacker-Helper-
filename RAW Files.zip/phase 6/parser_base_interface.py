import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, List

logger = logging.getLogger("CyberForge.Parsers")

class BaseParser(ABC):
    """
    Abstract Base Class for all security tool output parsers.
    Ensures every parser returns a standardized list of finding dictionaries
    that easily map to the SQLAlchemy Finding model.
    """
    
    def __init__(self, tool_name: str):
        self.tool_name = tool_name

    @abstractmethod
    def parse(self, raw_output: str, target: str) -> List[Dict[str, Any]]:
        """
        Takes the raw stdout/file-content from a tool and standardizes it.
        Must return a list of dictionaries representing normalized findings.
        """
        pass

    def _create_standard_finding(
        self,
        title: str,
        description: str,
        affected_asset: str,
        severity: str,
        affected_service: str = None,
        cvss_score: float = None,
        cve_id: str = None,
        cwe_id: str = None
    ) -> Dict[str, Any]:
        """
        Helper method to enforce the exact schema required by our database.
        """
        return {
            "title": title[:255],
            "description": description,
            "affected_asset": affected_asset[:255],
            "affected_service": affected_service[:255] if affected_service else None,
            "severity": severity.capitalize(),
            "cvss_score": cvss_score,
            "cve_id": cve_id[:50] if cve_id else None,
            "cwe_id": cwe_id[:50] if cwe_id else None,
            "confidence": "Confirmed" # Tool outputs are generally considered confirmed facts (e.g., a port is open)
        }
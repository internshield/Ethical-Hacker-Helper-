import logging
from typing import Dict, Any, List
from app.parsers.base import BaseParser
from app.parsers.nmap_parser import NmapParser
from app.parsers.nuclei_parser import NucleiParser

logger = logging.getLogger("CyberForge.ParserManager")

class ParserManager:
    """
    Central registry for all tool parsers.
    Routes raw tool output to the correct parser based on the tool name.
    """
    def __init__(self):
        self._parsers: Dict[str, BaseParser] = {
            "nmap": NmapParser(),
            "nuclei": NucleiParser(),
        }

    def parse_results(self, tool_name: str, raw_output: str, target: str) -> List[Dict[str, Any]]:
        """
        Locates the appropriate parser and standardizes the output.
        """
        tool_name = tool_name.lower()
        if tool_name not in self._parsers:
            logger.error(f"No parser registered for tool: {tool_name}")
            return []
            
        parser = self._parsers[tool_name]
        logger.info(f"Parsing raw output using {tool_name} parser for target: {target}")
        
        return parser.parse(raw_output, target)

# Global instance for dependency injection
parser_manager = ParserManager()
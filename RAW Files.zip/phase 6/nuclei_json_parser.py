import json
import logging
from typing import Dict, Any, List
from app.parsers.base import BaseParser

logger = logging.getLogger("CyberForge.Parsers.Nuclei")

class NucleiParser(BaseParser):
    def __init__(self):
        super().__init__("nuclei")

    def parse(self, raw_output: str, target: str) -> List[Dict[str, Any]]:
        """
        Parses Nuclei JSON-Lines output into standardized Vulnerability findings.
        """
        findings = []
        if not raw_output or not raw_output.strip():
            logger.warning("Empty Nuclei output provided for parsing.")
            return findings

        # Nuclei outputs multiple JSON objects separated by newlines (JSONL)
        lines = raw_output.strip().split('\n')
        
        for line in lines:
            if not line.strip():
                continue
                
            try:
                data = json.loads(line)
                
                info = data.get("info", {})
                template_id = data.get("template-id", "Unknown Template")
                name = info.get("name", template_id)
                severity = info.get("severity", "info").capitalize()
                
                # Standardize severity mapping if needed
                if severity == "Info":
                    severity = "Informational"
                    
                description = info.get("description", "No description provided.")
                extracted_results = data.get("extracted-results", [])
                
                if extracted_results:
                    description += f"\n\nExtracted Evidence:\n" + "\n".join(extracted_results)

                # Extract Classification Data (CVE, CVSS)
                classification = info.get("classification", {})
                cve_id = None
                if classification.get("cve-id"):
                    cve_id = classification.get("cve-id")[0] if isinstance(classification.get("cve-id"), list) else classification.get("cve-id")
                
                cvss_score = classification.get("cvss-score", 0.0)
                cwe_id = classification.get("cwe-id", [""])[0] if classification.get("cwe-id") else None

                finding = self._create_standard_finding(
                    title=name,
                    description=description,
                    affected_asset=data.get("host", target),
                    affected_service=data.get("matched-at", target),
                    severity=severity,
                    cvss_score=cvss_score,
                    cve_id=cve_id,
                    cwe_id=cwe_id
                )
                findings.append(finding)

            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse Nuclei JSON line: {e}")
            except Exception as e:
                logger.error(f"Unexpected error parsing Nuclei output: {e}")

        return findings
import xml.etree.ElementTree as ET
import logging
from typing import Dict, Any, List
from app.parsers.base import BaseParser

logger = logging.getLogger("CyberForge.Parsers.Nmap")

class NmapParser(BaseParser):
    def __init__(self):
        super().__init__("nmap")

    def parse(self, raw_output: str, target: str) -> List[Dict[str, Any]]:
        """
        Parses Nmap XML output (-oX) into standardized Informational findings
        representing open ports and discovered services.
        """
        findings = []
        if not raw_output or not raw_output.strip():
            logger.warning("Empty Nmap output provided for parsing.")
            return findings

        try:
            root = ET.fromstring(raw_output)
            
            for host in root.findall('host'):
                # Check if host is up
                status = host.find('status')
                if status is not None and status.get('state') != 'up':
                    continue

                # Extract IP address
                address = host.find('address')
                ip_addr = address.get('addr') if address is not None else target

                # Parse Ports
                ports = host.find('ports')
                if ports is not None:
                    for port in ports.findall('port'):
                        state = port.find('state')
                        if state is not None and state.get('state') == 'open':
                            port_id = port.get('portid')
                            protocol = port.get('protocol')
                            
                            service = port.find('service')
                            service_name = service.get('name') if service is not None else "unknown"
                            product = service.get('product') if service is not None else ""
                            version = service.get('version') if service is not None else ""
                            
                            service_str = f"{service_name} ({product} {version})".strip()
                            description = f"Open port discovered: {port_id}/{protocol}. Service identified as {service_str}."

                            finding = self._create_standard_finding(
                                title=f"Open Port: {port_id}/{protocol} ({service_name})",
                                description=description,
                                affected_asset=ip_addr,
                                affected_service=f"{protocol}/{port_id}",
                                severity="Informational"
                            )
                            findings.append(finding)

        except ET.ParseError as e:
            logger.error(f"Failed to parse Nmap XML: {e}")
        except Exception as e:
            logger.error(f"Unexpected error in Nmap parser: {e}")

        return findings
import logging
from sqlalchemy.orm import Session
from fastapi import HTTPException
from app.models.models import Case, Target, ToolRun, Finding, Tool
from app.schemas.case import CaseCreate, ToolExecutionRequest
from app.integrations.manager import tool_manager
from app.parsers.manager import parser_manager

logger = logging.getLogger("CyberForge.AssessmentService")

class AssessmentService:
    """
    Handles the core business logic for managing an assessment lifecycle.
    """
    
    @staticmethod
    def create_case(db: Session, case_data: CaseCreate) -> Case:
        # 1. Create the Case
        new_case = Case(
            name=case_data.name,
            client=case_data.client,
            assessment_type=case_data.assessment_type,
            operator=case_data.operator,
            scope=case_data.scope,
            out_of_scope=case_data.out_of_scope,
            rules_of_engagement=case_data.rules_of_engagement
        )
        db.add(new_case)
        db.commit()
        db.refresh(new_case)

        # 2. Add Initial Targets if provided
        if case_data.targets:
            for target_data in case_data.targets:
                new_target = Target(**target_data.model_dump(), case_id=new_case.id)
                db.add(new_target)
            db.commit()
            
        logger.info(f"Created new case: {new_case.name} (ID: {new_case.id})")
        return new_case

    @staticmethod
    async def execute_and_process_tool(db: Session, case_id: int, request: ToolExecutionRequest) -> dict:
        """
        The Master Orchestrator: Validates scope, runs a tool, parses output, and saves findings.
        """
        # 1. Fetch Context
        case = db.query(Case).filter(Case.id == case_id).first()
        target = db.query(Target).filter(Target.id == request.target_id, Target.case_id == case_id).first()
        
        if not case or not target:
            raise HTTPException(status_code=404, detail="Case or Target not found.")

        # 2. Execute Tool (Integration Engine handles scope validation natively)
        logger.info(f"Initiating {request.tool_name} against {target.identifier}")
        execution_result = await tool_manager.execute_tool(
            tool_name=request.tool_name,
            target=target.identifier,
            allowed_scope=case.scope,
            custom_flags=request.custom_flags
        )

        if execution_result.get("status") == "error":
            raise HTTPException(status_code=400, detail=execution_result.get("message"))

        # 3. Log the Tool Run for Audit Trail
        tool_run = ToolRun(
            case_id=case_id,
            tool_id=1,  # Placeholder: Should dynamically resolve tool ID from DB
            command_executed=execution_result.get("command", "Unknown"),
            operator=request.operator
        )
        db.add(tool_run)

        # 4. Parse Results into Findings
        raw_output = execution_result.get("raw_output", "")
        findings_data = parser_manager.parse_results(request.tool_name, raw_output, target.identifier)
        
        # 5. Save Findings
        saved_findings = []
        for f_data in findings_data:
            new_finding = Finding(**f_data, case_id=case_id)
            db.add(new_finding)
            saved_findings.append(new_finding)
            
        db.commit()
        
        logger.info(f"Successfully processed {request.tool_name}. Generated {len(saved_findings)} findings.")
        
        return {
            "status": "success",
            "findings_generated": len(saved_findings),
            "command_executed": execution_result.get("command")
        }

assessment_service = AssessmentService()
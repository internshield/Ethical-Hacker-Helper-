from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.models.database import get_db
from app.schemas.case import CaseCreate, CaseResponse, ToolExecutionRequest
from app.services.assessment import assessment_service

router = APIRouter(prefix="/cases", tags=["Assessment Workflow"])

@router.post("/", response_model=CaseResponse, status_code=201)
def create_new_case(case_data: CaseCreate, db: Session = Depends(get_db)):
    """
    Creates a new security assessment case with strict scope boundaries.
    """
    return assessment_service.create_case(db, case_data)

@router.post("/{case_id}/tools/execute")
async def run_assessment_tool(
    case_id: int, 
    request: ToolExecutionRequest, 
    db: Session = Depends(get_db)
):
    """
    Triggers an authorized tool execution against a target within the case.
    The output is automatically parsed and saved as findings.
    """
    return await assessment_service.execute_and_process_tool(db, case_id, request)
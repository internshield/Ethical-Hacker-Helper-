from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class TargetBase(BaseModel):
    identifier: str = Field(..., description="IP, Domain, or URL")
    target_type: str = Field(..., description="'IP', 'Domain', 'API Endpoint'")

class TargetCreate(TargetBase):
    pass

class TargetResponse(TargetBase):
    id: int
    case_id: int
    status: str
    class Config:
        from_attributes = True

class CaseBase(BaseModel):
    name: str = Field(..., max_length=255)
    client: str = Field(..., max_length=255)
    assessment_type: str = Field(..., max_length=100)
    operator: str = Field(..., max_length=100)
    scope: List[str] = Field(default_factory=list, description="List of authorized IPs/Domains")
    out_of_scope: List[str] = Field(default_factory=list)
    rules_of_engagement: Optional[str] = None

class CaseCreate(CaseBase):
    targets: Optional[List[TargetCreate]] = None

class CaseResponse(CaseBase):
    id: int
    start_date: datetime
    end_date: Optional[datetime]
    status: str
    targets: List[TargetResponse] = []
    
    class Config:
        from_attributes = True

class ToolExecutionRequest(BaseModel):
    target_id: int
    tool_name: str
    custom_flags: Optional[str] = None
    operator: str
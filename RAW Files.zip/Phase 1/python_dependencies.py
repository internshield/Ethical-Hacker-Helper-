# Web Framework & Server
fastapi==0.110.0
uvicorn[standard]==0.29.0
jinja2==3.1.3
python-multipart==0.0.9

# Database & Validation
SQLAlchemy==2.0.28
pydantic==2.6.4
pydantic-settings==2.2.1
alembic==1.13.1

# AI Integrations
openai==1.14.2
anthropic==0.21.3
langchain-core==0.1.33 # For standardized prompt templating

# Parsing & Utilities
beautifulsoup4==4.12.3
python-nmap==0.7.1
xmltodict==0.13.0
PyYAML==6.0.1
python-dotenv==1.0.1

# Reporting
WeasyPrint==61.2 # For high-quality PDF generation
markdown==3.6

# Security & Crypto
passlib[bcrypt]==1.7.4
python-jose[cryptography]==3.3.0
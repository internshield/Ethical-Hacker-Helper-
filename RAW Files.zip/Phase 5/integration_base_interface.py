import logging
import asyncio
import shutil
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from app.config import settings

logger = logging.getLogger("CyberForge.Integration")

class BaseToolAdapter(ABC):
    """
    Abstract Base Class for all security tool integrations.
    Ensures a standardized interface and enforces execution guardrails.
    """
    
    def __init__(self, tool_name: str):
        self.tool_name = tool_name

    def is_installed(self) -> bool:
        """
        Checks if the underlying CLI tool is installed on the host system.
        """
        return shutil.which(self.tool_name.lower()) is not None

    def validate_scope(self, target: str, allowed_scope: List[str]) -> bool:
        """
        SECURITY GUARDRAIL: Validates that the requested target is explicitly authorized.
        """
        if not settings.ENFORCE_STRICT_SCOPE:
            logger.warning(f"[{self.tool_name}] Strict scope enforcement is globally disabled!")
            return True
            
        # Basic exact match implementation (Can be expanded to handle CIDR blocks)
        if target not in allowed_scope:
            logger.error(f"[{self.tool_name}] Scope Violation Blocked: {target} is not in the authorized scope {allowed_scope}")
            return False
        return True

    @abstractmethod
    async def execute(self, target: str, allowed_scope: List[str], custom_flags: Optional[str] = None) -> Dict[str, Any]:
        """
        Executes the tool against the target asynchronously.
        Must return a standardized dictionary with status, stdout, and stderr.
        """
        pass
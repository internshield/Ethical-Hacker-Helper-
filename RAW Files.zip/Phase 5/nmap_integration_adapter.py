import asyncio
import logging
from typing import Dict, Any, List, Optional
from app.integrations.base import BaseToolAdapter
from app.config import settings

logger = logging.getLogger("CyberForge.Nmap")

class NmapAdapter(BaseToolAdapter):
    def __init__(self):
        super().__init__("nmap")

    async def execute(self, target: str, allowed_scope: List[str], custom_flags: Optional[str] = None) -> Dict[str, Any]:
        """
        Executes Nmap safely with an XML output format for downstream parsing.
        """
        if not self.is_installed():
            return {"status": "error", "message": "Nmap is not installed on the system."}

        if not self.validate_scope(target, allowed_scope):
            return {"status": "error", "message": f"Target {target} is out of scope."}

        # Default to a safe version scan with XML output
        flags = custom_flags if custom_flags else "-sV -O"
        
        # Security Guardrail: Strip dangerous flags (like output redirection that could overwrite system files)
        if ">" in flags or "|" in flags or ";" in flags:
             return {"status": "error", "message": "Dangerous shell characters detected in custom flags."}

        command = f"nmap {flags} -oX - {target}"
        logger.info(f"[Nmap] Executing authorized scan: {command}")

        try:
            process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await process.communicate()
            
            return {
                "status": "success" if process.returncode == 0 else "failed",
                "raw_output": stdout.decode('utf-8', errors='ignore'),
                "error_output": stderr.decode('utf-8', errors='ignore'),
                "command": command
            }
        except Exception as e:
            logger.error(f"[Nmap] Execution exception: {str(e)}")
            return {"status": "error", "message": str(e)}
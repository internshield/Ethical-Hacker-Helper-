import asyncio
import logging
from typing import Dict, Any, List, Optional
from app.integrations.base import BaseToolAdapter

logger = logging.getLogger("CyberForge.Nuclei")

class NucleiAdapter(BaseToolAdapter):
    def __init__(self):
        super().__init__("nuclei")

    async def execute(self, target: str, allowed_scope: List[str], custom_flags: Optional[str] = None) -> Dict[str, Any]:
        """
        Executes ProjectDiscovery's Nuclei scanner with JSON output.
        """
        if not self.is_installed():
            return {"status": "error", "message": "Nuclei is not installed on the system."}

        if not self.validate_scope(target, allowed_scope):
            return {"status": "error", "message": f"Target {target} is out of scope."}

        # Enforce JSON output for standard parsing
        flags = custom_flags if custom_flags else "-t cves/"
        command = f"nuclei -u {target} {flags} -json-export -"
        
        if ">" in flags or "|" in flags or ";" in flags:
             return {"status": "error", "message": "Dangerous shell characters detected in custom flags."}

        logger.info(f"[Nuclei] Executing authorized scan: {command}")

        try:
            process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await process.communicate()
            
            return {
                "status": "success" if process.returncode == 0 else "failed",
                "raw_output": stdout.decode('utf-8', errors='ignore'),
                "error_output": stderr.decode('utf-8', errors='ignore'),
                "command": command
            }
        except Exception as e:
            logger.error(f"[Nuclei] Execution exception: {str(e)}")
            return {"status": "error", "message": str(e)}
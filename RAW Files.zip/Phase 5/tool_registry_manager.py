import logging
from typing import Dict, Any, List
from app.integrations.base import BaseToolAdapter
from app.integrations.nmap_adapter import NmapAdapter
from app.integrations.nuclei_adapter import NucleiAdapter

logger = logging.getLogger("CyberForge.ToolManager")

class ToolManager:
    """
    Central registry for all supported security tools.
    Allows dynamic execution of tools based on API requests.
    """
    def __init__(self):
        self._adapters: Dict[str, BaseToolAdapter] = {
            "nmap": NmapAdapter(),
            "nuclei": NucleiAdapter(),
            # Future integrations (ZAP, Nikto, etc.) are easily registered here.
        }

    def get_supported_tools(self) -> List[Dict[str, Any]]:
        """
        Returns a list of tools and their current installation status on the host system.
        """
        return [
            {
                "name": name,
                "installed": adapter.is_installed()
            }
            for name, adapter in self._adapters.items()
        ]

    async def execute_tool(self, tool_name: str, target: str, allowed_scope: List[str], custom_flags: str = None) -> Dict[str, Any]:
        """
        Routes the execution request to the appropriate tool adapter.
        """
        tool_name = tool_name.lower()
        if tool_name not in self._adapters:
            return {"status": "error", "message": f"Tool '{tool_name}' is not supported by CyberForge."}
            
        adapter = self._adapters[tool_name]
        logger.info(f"Delegating execution to {tool_name} adapter for target: {target}")
        
        return await adapter.execute(target, allowed_scope, custom_flags)

# Global instance for dependency injection
tool_manager = ToolManager()
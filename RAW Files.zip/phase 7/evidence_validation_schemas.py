from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class EvidenceBase(BaseModel):
    description: Optional[str] = Field(None, description="Context or description of what this evidence proves.")
    finding_id: Optional[int] = Field(None, description="Optional ID of the finding this evidence belongs to.")

class EvidenceCreate(EvidenceBase):
    case_id: int = Field(..., description="The ID of the case this evidence is attached to.")

class EvidenceResponse(EvidenceBase):
    id: int
    case_id: int
    filename: str
    sha256: str = Field(..., description="Cryptographic hash ensuring the evidence has not been tampered with.")
    size_bytes: int
    collected_by: str
    timestamp: datetime

    class Config:
        from_attributes = True
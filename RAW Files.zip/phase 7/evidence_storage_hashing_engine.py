import os
import hashlib
import shutil
import logging
from datetime import datetime
from typing import Optional
from fastapi import UploadFile
from sqlalchemy.orm import Session

from app.models.models import Evidence
from app.config import settings

logger = logging.getLogger("CyberForge.Evidence")

class EvidenceManager:
    """
    Handles the secure ingestion, hashing, and storage of assessment evidence
    such as screenshots, PCAP files, and raw tool logs.
    """
    def __init__(self):
        self.base_dir = "./data/evidence"
        os.makedirs(self.base_dir, exist_ok=True)

    def _calculate_sha256(self, file_path: str) -> str:
        """
        Calculates the SHA-256 hash of a file by reading it in chunks.
        Vital for maintaining an immutable audit trail of findings.
        """
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            # Read in 4K blocks to avoid memory exhaustion on large PCAPs
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    def _secure_filename(self, filename: str) -> str:
        """
        Sanitizes the filename to prevent directory traversal attacks (e.g., ../../)
        """
        keepcharacters = ('.', '_', '-')
        sanitized = "".join(c for c in filename if c.isalnum() or c in keepcharacters).rstrip()
        if not sanitized:
            return "unnamed_evidence.bin"
        return sanitized

    async def save_evidence(
        self,
        db: Session,
        upload_file: UploadFile,
        case_id: int,
        operator: str,
        finding_id: Optional[int] = None,
        description: Optional[str] = None
    ) -> Evidence:
        """
        Saves an uploaded file to disk, calculates its SHA-256 hash for integrity,
        and records its metadata in the SQLite/PostgreSQL database.
        """
        safe_filename = self._secure_filename(upload_file.filename)
        
        # Prepend case ID and timestamp to ensure uniqueness and logical grouping on disk
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        unique_filename = f"case{case_id}_{timestamp}_{safe_filename}"
        file_path = os.path.join(self.base_dir, unique_filename)

        # Securely stream the uploaded file to disk
        try:
            with open(file_path, "wb") as buffer:
                shutil.copyfileobj(upload_file.file, buffer)
        except Exception as e:
            logger.error(f"Failed to write evidence to disk: {e}")
            raise RuntimeError(f"Failed to securely store evidence file: {safe_filename}")

        # Calculate cryptographic integrity hash and size
        file_hash = self._calculate_sha256(file_path)
        file_size = os.path.getsize(file_path)

        # Create the immutable Database Record
        evidence_record = Evidence(
            case_id=case_id,
            finding_id=finding_id,
            filename=safe_filename,
            sha256=file_hash,
            size_bytes=file_size,
            filepath=file_path,
            description=description,
            collected_by=operator
        )

        db.add(evidence_record)
        db.commit()
        db.refresh(evidence_record)

        logger.info(f"Evidence saved successfully: {safe_filename} | SHA256: {file_hash}")
        return evidence_record

    def get_evidence_path(self, db: Session, evidence_id: int, case_id: int) -> Optional[str]:
        """
        Retrieves the secure file path for downloading or viewing evidence.
        """
        evidence = db.query(Evidence).filter(
            Evidence.id == evidence_id,
            Evidence.case_id == case_id
        ).first()
        
        if evidence and os.path.exists(evidence.filepath):
            return evidence.filepath
        return None

# Global instance for dependency injection across API routes
evidence_manager = EvidenceManager()
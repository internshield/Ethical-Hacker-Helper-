import os
from typing import Dict, Any
from openai import OpenAI, AzureOpenAI
from anthropic import Anthropic
from app.ai.base import BaseAIProvider
from app.config import settings

class OpenAIProvider(BaseAIProvider):
    def __init__(self):
        super().__init__()
        self.provider_name = "OpenAI"
        self.client = OpenAI(api_key=settings.OPENAI_API_KEY)
        self.model = "gpt-4-turbo-preview" # Defaulting to latest reasoning model

    def _call_api(self, prompt: str) -> Dict[str, Any]:
        secured_prompt = self._inject_security_guardrails(prompt)
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": secured_prompt}],
            temperature=0.2, # Low temperature for analytical consistency
        )
        return {
            "analysis": response.choices[0].message.content,
            "tokens_used": response.usage.total_tokens,
            "model": self.model
        }

    def analyze_evidence(self, context: str, evidence: str) -> Dict[str, Any]:
        prompt = f"Context: {context}\n\nEvidence/Tool Output:\n{evidence}\n\nPlease analyze this security data."
        return self.execute_with_retry(self._call_api, prompt)


class AzureOpenAIProvider(BaseAIProvider):
    def __init__(self):
        super().__init__()
        self.provider_name = "AzureOpenAI"
        self.client = AzureOpenAI(
            api_key=settings.AZURE_OPENAI_API_KEY,
            api_version=settings.AZURE_OPENAI_API_VERSION,
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT
        )
        self.deployment_name = settings.AZURE_OPENAI_DEPLOYMENT_NAME

    def _call_api(self, prompt: str) -> Dict[str, Any]:
        secured_prompt = self._inject_security_guardrails(prompt)
        response = self.client.chat.completions.create(
            model=self.deployment_name,
            messages=[{"role": "user", "content": secured_prompt}],
            temperature=0.2,
        )
        return {
            "analysis": response.choices[0].message.content,
            "tokens_used": response.usage.total_tokens,
            "model": self.deployment_name
        }

    def analyze_evidence(self, context: str, evidence: str) -> Dict[str, Any]:
        prompt = f"Context: {context}\n\nEvidence/Tool Output:\n{evidence}\n\nPlease analyze this security data."
        return self.execute_with_retry(self._call_api, prompt)


class AnthropicProvider(BaseAIProvider):
    def __init__(self):
        super().__init__()
        self.provider_name = "Anthropic"
        self.client = Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        self.model = "claude-3-opus-20240229"

    def _call_api(self, prompt: str) -> Dict[str, Any]:
        secured_prompt = self._inject_security_guardrails(prompt)
        response = self.client.messages.create(
            model=self.model,
            max_tokens=4000,
            temperature=0.2,
            messages=[{"role": "user", "content": secured_prompt}]
        )
        return {
            "analysis": response.content[0].text,
            "tokens_used": response.usage.input_tokens + response.usage.output_tokens,
            "model": self.model
        }

    def analyze_evidence(self, context: str, evidence: str) -> Dict[str, Any]:
        prompt = f"Context: {context}\n\nEvidence/Tool Output:\n{evidence}\n\nPlease analyze this security data."
        return self.execute_with_retry(self._call_api, prompt)
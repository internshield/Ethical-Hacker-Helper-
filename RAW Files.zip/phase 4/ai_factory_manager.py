import logging
from typing import Dict, Any
from app.config import settings
from app.ai.base import BaseAIProvider
from app.ai.providers import OpenAIProvider, AzureOpenAIProvider, AnthropicProvider

logger = logging.getLogger("CyberForge.AIManager")

class AIManager:
    """
    Factory class to instantiate and manage the correct AI provider based on configuration.
    Handles fallbacks and abstracts the underlying provider from the business logic.
    """
    def __init__(self):
        self.provider = self._initialize_provider()

    def _initialize_provider(self) -> BaseAIProvider:
        pref = settings.PRIMARY_AI_PROVIDER.upper()
        
        # Explicit Selections
        if pref == "OPENAI" and settings.OPENAI_API_KEY:
            logger.info("Initializing OpenAI Provider.")
            return OpenAIProvider()
        elif pref == "ANTHROPIC" and settings.ANTHROPIC_API_KEY:
            logger.info("Initializing Anthropic Provider.")
            return AnthropicProvider()
        elif pref == "AZURE" and settings.AZURE_OPENAI_API_KEY:
            logger.info("Initializing Azure OpenAI Provider.")
            return AzureOpenAIProvider()
            
        # AUTO Selection (Fallback Logic)
        if settings.OPENAI_API_KEY:
            logger.info("AUTO mode selected: Defaulting to OpenAI Provider.")
            return OpenAIProvider()
        elif settings.AZURE_OPENAI_API_KEY:
            logger.info("AUTO mode selected: Defaulting to Azure OpenAI Provider.")
            return AzureOpenAIProvider()
        elif settings.ANTHROPIC_API_KEY:
            logger.info("AUTO mode selected: Defaulting to Anthropic Provider.")
            return AnthropicProvider()
            
        logger.warning("No valid AI Provider configuration found. AI features will be disabled.")
        return None

    def analyze_finding(self, context: str, evidence: str) -> Dict[str, Any]:
        """
        Primary entry point for the application to request AI analysis.
        """
        if not self.provider:
            return {
                "analysis": "[AI Analysis Disabled] - No valid API keys configured.",
                "tokens_used": 0,
                "model": "None"
            }
            
        logger.info(f"Routing analysis request via {self.provider.provider_name}")
        return self.provider.analyze_evidence(context, evidence)

# Instantiate a global instance for dependency injection
ai_manager = AIManager()
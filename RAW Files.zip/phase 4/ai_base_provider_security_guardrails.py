import logging
import time
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from app.config import settings

logger = logging.getLogger("CyberForge.AI")

class BaseAIProvider(ABC):
    """
    Abstract Base Class for all AI Providers (OpenAI, Anthropic, Azure).
    Enforces strict structural and security requirements.
    """
    
    def __init__(self):
        self.provider_name = "Base"
        self.max_retries = 3
        self.base_delay = 2  # seconds

    # --- SECURITY GUARDRAIL INJECTION ---
    def _inject_security_guardrails(self, prompt: str) -> str:
        """
        Critically important: Appends explicit rules of engagement to EVERY prompt.
        Prevents the AI from generating autonomous attack scripts or hallucinating out-of-scope targets.
        """
        guardrail = (
            "\n\n--- SYSTEM DIRECTIVE ---\n"
            "You are CyberForge, an AI assistant for an AUTHORIZED ethical hacker.\n"
            "1. Do NOT generate autonomous exploitation scripts.\n"
            "2. Limit all analysis strictly to the provided evidence.\n"
            "3. If asked to formulate a command, ensure it is non-destructive and safe.\n"
            "4. Maintain a highly professional, objective, and analytical tone suitable for a corporate report."
        )
        return prompt + guardrail

    def execute_with_retry(self, func, *args, **kwargs) -> Dict[str, Any]:
        """
        Executes an API call with exponential backoff to handle rate limits and timeouts.
        """
        for attempt in range(self.max_retries):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                wait_time = self.base_delay * (2 ** attempt)
                logger.warning(f"[{self.provider_name}] API Error: {str(e)}. Retrying in {wait_time}s... (Attempt {attempt + 1}/{self.max_retries})")
                
                # Do not expose raw exception text if it might contain API keys (handled by logger config, but being safe)
                if "key" in str(e).lower() or "token" in str(e).lower():
                    logger.error(f"[{self.provider_name}] Authentication or Key Error detected. Check environment variables.")
                    raise RuntimeError("AI Provider Authentication Failed. Check server logs.")
                
                time.sleep(wait_time)
                
        logger.error(f"[{self.provider_name}] Max retries exceeded.")
        raise RuntimeError(f"{self.provider_name} API is currently unreachable or heavily rate-limited.")

    @abstractmethod
    def analyze_evidence(self, context: str, evidence: str) -> Dict[str, Any]:
        """
        Standardized method to analyze security tool output or evidence.
        Must return a dict containing 'analysis' and 'tokens_used'.
        """
        pass
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from app.config import settings
from app.routes.api import api_router

# Configure Application Logging
logging.basicConfig(
    level=logging.INFO if settings.APP_ENV == "production" else logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("CyberForge")

def create_app() -> FastAPI:
    """
    Factory function to create and configure the FastAPI application instance.
    """
    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        description="AI-Powered Ethical Hacking Workbench & Security Assessment Reporting Platform",
        docs_url="/api/docs",
        redoc_url="/api/redoc"
    )

    # Configure Cross-Origin Resource Sharing (CORS)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.ALLOWED_HOSTS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Register Routers
    app.include_router(api_router)

    # Global Exception Handler for consistent API responses
    @app.exception_handler(Exception)
    async def global_exception_handler(request, exc):
        logger.error(f"Unhandled system error: {exc}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content={
                "error": "Internal Server Error",
                "message": "An unexpected error occurred in the assessment platform.",
                "details": str(exc) if settings.APP_ENV == "development" else None
            }
        )

    @app.on_event("startup")
    async def startup_event():
        logger.info(f"Starting {settings.APP_NAME} v{settings.APP_VERSION}...")
        logger.info(f"Strict Scope Enforcement: {settings.ENFORCE_STRICT_SCOPE}")

    return app

# Instantiate the application
app = create_app()

if __name__ == "__main__":
    import uvicorn
    # Entry point for running the application directly via `python main.py`
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=settings.APP_PORT,
        reload=True if settings.APP_ENV == "development" else False
    )
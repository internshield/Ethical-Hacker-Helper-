# CyberForge AI Application Package
# Defines the core application module
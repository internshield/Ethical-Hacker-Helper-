from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import List
import os

class Settings(BaseSettings):
    # Application Settings
    APP_NAME: str = "CyberForge AI"
    APP_VERSION: str = "1.0.0"
    APP_ENV: str = "development"
    APP_PORT: int = 8000
    SECRET_KEY: str = "super_secret_default_key_change_in_production"
    ALLOWED_HOSTS: List[str] = ["*"]
    
    # Database
    DATABASE_URL: str = "sqlite:///./data/cyberforge.db"
    
    # AI Provider Settings
    PRIMARY_AI_PROVIDER: str = "AUTO"
    OPENAI_API_KEY: str | None = None
    ANTHROPIC_API_KEY: str | None = None
    AZURE_OPENAI_API_KEY: str | None = None
    AZURE_OPENAI_ENDPOINT: str | None = None
    AZURE_OPENAI_DEPLOYMENT_NAME: str | None = None
    AZURE_OPENAI_API_VERSION: str = "2024-02-15-preview"
    
    # Security & Scope Enforcements
    REQUIRE_AUTH: bool = False
    ENFORCE_STRICT_SCOPE: bool = True
    REQUIRE_OPERATOR_CONFIRMATION: bool = True
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

# Create a global settings instance
settings = Settings()

# Ensure data directories exist
os.makedirs("./data/evidence", exist_ok=True)
os.makedirs("./data/exports", exist_ok=True)
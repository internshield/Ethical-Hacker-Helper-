from fastapi import APIRouter, Request
from datetime import datetime
from app.config import settings

# Create the main API router
api_router = APIRouter(prefix="/api/v1")

@api_router.get("/health", tags=["System"])
async def health_check(request: Request):
    """
    Core system health check endpoint.
    Verifies that the API is responding and returns basic system configuration states.
    """
    return {
        "status": "online",
        "timestamp": datetime.utcnow().isoformat(),
        "app_name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "environment": settings.APP_ENV,
        "security_enforcements": {
            "strict_scope": settings.ENFORCE_STRICT_SCOPE,
            "operator_confirmation_required": settings.REQUIRE_OPERATOR_CONFIRMATION
        }
    }
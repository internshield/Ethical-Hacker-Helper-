from typing import Generator
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from app.config import settings

# Configure the SQLAlchemy Engine
# The connect_args={"check_same_thread": False} is required for FastAPI + SQLite
# It will be ignored if DATABASE_URL is changed to PostgreSQL later.
engine_args = {}
if settings.DATABASE_URL.startswith("sqlite"):
    engine_args["connect_args"] = {"check_same_thread": False}

engine = create_engine(
    settings.DATABASE_URL,
    echo=settings.APP_ENV == "development",  # Log SQL queries in dev mode
    **engine_args
)

# Create a configured "Session" class
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create a Base class for our declarative models
Base = declarative_base()

def get_db() -> Generator:
    """
    Dependency function to yield a database session for FastAPI routes.
    Ensures the session is cleanly closed after the request is processed.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
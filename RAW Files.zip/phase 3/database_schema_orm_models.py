from datetime import datetime
from typing import List, Optional
from sqlalchemy import String, Text, Integer, ForeignKey, DateTime, Boolean, Float, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.models.database import Base

class Case(Base):
    __tablename__ = "cases"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(255), index=True)
    client: Mapped[str] = mapped_column(String(255))
    assessment_type: Mapped[str] = mapped_column(String(100))
    operator: Mapped[str] = mapped_column(String(100))
    
    # Scope Definition (Strictly enforced by the platform)
    scope: Mapped[dict] = mapped_column(JSON, default=list) # List of in-scope IPs/Domains
    out_of_scope: Mapped[dict] = mapped_column(JSON, default=list)
    rules_of_engagement: Mapped[str] = mapped_column(Text, nullable=True)
    
    start_date: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    end_date: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="Open")  # Open, In Progress, Review, Closed
    
    # Relationships
    targets: Mapped[List["Target"]] = relationship("Target", back_populates="case", cascade="all, delete-orphan")
    findings: Mapped[List["Finding"]] = relationship("Finding", back_populates="case", cascade="all, delete-orphan")
    evidence: Mapped[List["Evidence"]] = relationship("Evidence", back_populates="case", cascade="all, delete-orphan")
    steps: Mapped[List["AssessmentStep"]] = relationship("AssessmentStep", back_populates="case", cascade="all, delete-orphan")
    reports: Mapped[List["Report"]] = relationship("Report", back_populates="case", cascade="all, delete-orphan")

class Target(Base):
    __tablename__ = "targets"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"))
    identifier: Mapped[str] = mapped_column(String(255), index=True) # IP, Domain, URL
    target_type: Mapped[str] = mapped_column(String(50)) # e.g., 'IP', 'Domain', 'API Endpoint'
    status: Mapped[str] = mapped_column(String(50), default="Pending")
    
    case: Mapped["Case"] = relationship("Case", back_populates="targets")

class AssessmentStep(Base):
    __tablename__ = "assessment_steps"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"))
    step_name: Mapped[str] = mapped_column(String(100)) # e.g., 'Reconnaissance', 'Scanning'
    status: Mapped[str] = mapped_column(String(50), default="Not Started") # Not Started, In Progress, Completed
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    operator: Mapped[str] = mapped_column(String(100))
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    case: Mapped["Case"] = relationship("Case", back_populates="steps")

class Tool(Base):
    __tablename__ = "tools"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(100), unique=True)
    version: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="Available") # Available, Missing, Misconfigured
    
    runs: Mapped[List["ToolRun"]] = relationship("ToolRun", back_populates="tool")

class ToolRun(Base):
    __tablename__ = "tool_runs"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"))
    tool_id: Mapped[int] = mapped_column(ForeignKey("tools.id"))
    command_executed: Mapped[str] = mapped_column(Text)
    raw_output_path: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    operator: Mapped[str] = mapped_column(String(100))
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    tool: Mapped["Tool"] = relationship("Tool", back_populates="runs")

class Finding(Base):
    __tablename__ = "findings"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"))
    title: Mapped[str] = mapped_column(String(255))
    description: Mapped[str] = mapped_column(Text)
    affected_asset: Mapped[str] = mapped_column(String(255))
    affected_service: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    
    # Risk Metrics
    severity: Mapped[str] = mapped_column(String(50)) # Informational, Low, Medium, High, Critical
    confidence: Mapped[str] = mapped_column(String(50), default="Tentative") # Tentative, Confirmed
    cvss_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    cve_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    cwe_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    
    # AI Review Guardrails
    ai_generated: Mapped[bool] = mapped_column(Boolean, default=False)
    human_reviewed: Mapped[bool] = mapped_column(Boolean, default=False)
    
    status: Mapped[str] = mapped_column(String(50), default="Open") # Open, Remediated, Accepted Risk
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    case: Mapped["Case"] = relationship("Case", back_populates="findings")
    evidence: Mapped[List["Evidence"]] = relationship("Evidence", back_populates="finding")
    recommendations: Mapped[List["Recommendation"]] = relationship("Recommendation", back_populates="finding", cascade="all, delete-orphan")
    iocs: Mapped[List["IOC"]] = relationship("IOC", back_populates="finding", cascade="all, delete-orphan")

class Evidence(Base):
    __tablename__ = "evidence"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"))
    finding_id: Mapped[Optional[int]] = mapped_column(ForeignKey("findings.id"), nullable=True)
    
    filename: Mapped[str] = mapped_column(String(255))
    sha256: Mapped[str] = mapped_column(String(64), index=True) # Integrity Hash
    size_bytes: Mapped[int] = mapped_column(Integer)
    filepath: Mapped[str] = mapped_column(String(500))
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    collected_by: Mapped[str] = mapped_column(String(100))
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    case: Mapped["Case"] = relationship("Case", back_populates="evidence")
    finding: Mapped["Finding"] = relationship("Finding", back_populates="evidence")

class Recommendation(Base):
    __tablename__ = "recommendations"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    finding_id: Mapped[int] = mapped_column(ForeignKey("findings.id"))
    description: Mapped[str] = mapped_column(Text)
    effort: Mapped[str] = mapped_column(String(50), default="Moderate") # Low, Moderate, High
    priority: Mapped[str] = mapped_column(String(50), default="Medium")
    
    finding: Mapped["Finding"] = relationship("Finding", back_populates="recommendations")

class IOC(Base):
    __tablename__ = "iocs"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"))
    finding_id: Mapped[Optional[int]] = mapped_column(ForeignKey("findings.id"), nullable=True)
    indicator: Mapped[str] = mapped_column(String(255), index=True)
    ioc_type: Mapped[str] = mapped_column(String(100)) # e.g., 'Malicious IP', 'File Hash'
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    finding: Mapped["Finding"] = relationship("Finding", back_populates="iocs")

class TimelineEvent(Base):
    __tablename__ = "timeline_events"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"))
    event_type: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(Text)
    operator: Mapped[str] = mapped_column(String(100))
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Report(Base):
    __tablename__ = "reports"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"))
    report_format: Mapped[str] = mapped_column(String(10)) # HTML, PDF, JSON
    filepath: Mapped[str] = mapped_column(String(500))
    generated_by: Mapped[str] = mapped_column(String(100))
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    case: Mapped["Case"] = relationship("Case", back_populates="reports")

class AIRequest(Base):
    __tablename__ = "ai_requests"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    case_id: Mapped[Optional[int]] = mapped_column(ForeignKey("cases.id"), nullable=True)
    provider: Mapped[str] = mapped_column(String(50))
    prompt: Mapped[str] = mapped_column(Text)
    tokens_used: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    
    responses: Mapped[List["AIResponse"]] = relationship("AIResponse", back_populates="request")

class AIResponse(Base):
    __tablename__ = "ai_responses"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    request_id: Mapped[int] = mapped_column(ForeignKey("ai_requests.id"))
    response_text: Mapped[str] = mapped_column(Text)
    ai_model: Mapped[str] = mapped_column(String(100))
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    request: Mapped["AIRequest"] = relationship("AIRequest", back_populates="responses")

class AuditLog(Base):
    """
    Immutable audit trail for all significant actions taken on the platform.
    Ensures ethical compliance and tracks operator interactions.
    """
    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    operator: Mapped[str] = mapped_column(String(100), index=True)
    action: Mapped[str] = mapped_column(String(255))
    target: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)